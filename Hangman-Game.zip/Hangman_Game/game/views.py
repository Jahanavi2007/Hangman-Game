import random

from django.shortcuts import render


WORDS = [
    "python",
    "django",
    "machine",
    "computer",
    "program"
]


def get_new_game():
    word = random.choice(WORDS)

    return {
        "word": word,
        "guessed_letters": [],
        "wrong_guesses": 0,
        "game_over": False,
        "won": False,
    }


def display_word(word, guessed_letters):
    result = []

    for letter in word:
        if letter in guessed_letters:
            result.append(letter.upper())
        else:
            result.append("_")

    return " ".join(result)


def home(request):

    if "word" not in request.session:
        game = get_new_game()

        request.session["word"] = game["word"]
        request.session["guessed_letters"] = game["guessed_letters"]
        request.session["wrong_guesses"] = game["wrong_guesses"]
        request.session["game_over"] = game["game_over"]
        request.session["won"] = game["won"]


    word = request.session["word"]

    guessed_letters = request.session.get(
        "guessed_letters",
        []
    )

    wrong_guesses = request.session.get(
        "wrong_guesses",
        0
    )

    game_over = request.session.get(
        "game_over",
        False
    )

    won = request.session.get(
        "won",
        False
    )


    message = ""


    if request.method == "POST":

        action = request.POST.get(
            "action",
            "guess"
        )


        # --------------------------------------------
        # NEW GAME
        # --------------------------------------------

        if action == "new_game":

            game = get_new_game()

            request.session["word"] = game["word"]
            request.session["guessed_letters"] = game["guessed_letters"]
            request.session["wrong_guesses"] = game["wrong_guesses"]
            request.session["game_over"] = game["game_over"]
            request.session["won"] = game["won"]

            return render(
                request,
                "game/index.html",
                {
                    "display_word": display_word(
                        game["word"],
                        game["guessed_letters"]
                    ),
                    "wrong_guesses": 0,
                    "max_wrong_guesses": 6,
                    "guessed_letters": [],
                    "game_over": False,
                    "won": False,
                    "message": "New game started!",
                }
            )


        # --------------------------------------------
        # GUESS LETTER
        # --------------------------------------------

        if (
            not game_over
            and not won
        ):

            letter = request.POST.get(
                "letter",
                ""
            ).strip().lower()


            # Only one alphabet letter

            if (
                len(letter) != 1
                or not letter.isalpha()
            ):

                message = "Please enter one letter."


            elif letter in guessed_letters:

                message = "You already guessed that letter."


            else:

                guessed_letters.append(letter)


                # -------------------------------
                # CORRECT GUESS
                # -------------------------------

                if letter in word:

                    message = "Correct guess! 🎉"


                # -------------------------------
                # WRONG GUESS
                # -------------------------------

                else:

                    wrong_guesses += 1

                    message = "Wrong guess!"


                # -------------------------------
                # CHECK WIN
                # -------------------------------

                if all(
                    character in guessed_letters
                    for character in word
                ):

                    won = True
                    game_over = True

                    message = (
                        "Congratulations! "
                        "You guessed the word! 🎉"
                    )


                # -------------------------------
                # CHECK GAME OVER
                # -------------------------------

                elif wrong_guesses >= 6:

                    game_over = True

                    message = (
                        f"Game Over! "
                        f"The word was {word.upper()}."
                    )


                # -------------------------------
                # SAVE SESSION
                # -------------------------------

                request.session["guessed_letters"] = (
                    guessed_letters
                )

                request.session["wrong_guesses"] = (
                    wrong_guesses
                )

                request.session["game_over"] = (
                    game_over
                )

                request.session["won"] = (
                    won
                )


    return render(
        request,
        "game/index.html",
        {
            "display_word": display_word(
                word,
                guessed_letters
            ),

            "wrong_guesses": wrong_guesses,

            "max_wrong_guesses": 6,

            "guessed_letters": guessed_letters,

            "game_over": game_over,

            "won": won,

            "message": message,
        }
    )