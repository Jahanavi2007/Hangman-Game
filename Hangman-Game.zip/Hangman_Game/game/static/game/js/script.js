document.addEventListener(
    "DOMContentLoaded",
    function () {

        const input =
            document.getElementById("letter");


        if (input) {

            input.focus();


            input.addEventListener(
                "input",
                function () {

                    this.value =
                        this.value
                            .replace(/[^a-zA-Z]/g, "")
                            .slice(0, 1);

                }
            );


            input.addEventListener(
                "keydown",
                function (event) {

                    if (
                        event.key === "Enter"
                        && this.value.length === 1
                    ) {

                        this.closest("form").submit();

                    }

                }
            );

        }

    }
);